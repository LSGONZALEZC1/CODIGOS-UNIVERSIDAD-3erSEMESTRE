from TDA_Pila import Pila, desapilar, pila_vacia, apilar

from TDA_Grafo import Grafo,barrido_profundidad,barrido_amplitude, marcar_no_visitados, buscar_vertices, existe_pasos, dijkstra, kruskal


